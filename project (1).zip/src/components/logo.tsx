
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      {/* Stylized Technical Monogram */}
      <div className="relative h-14 w-14 flex items-center justify-center shrink-0">
        <div className="absolute inset-0 rounded-full bg-[#135890] shadow-xl overflow-hidden border-2 border-[#135890]/20">
          <svg
            viewBox="0 0 100 100"
            className="absolute inset-0 h-full w-full opacity-40"
          >
            <circle cx="50" cy="50" r="48" fill="none" stroke="white" strokeWidth="0.5" />
            <path 
              d="M20 20 L80 80 M80 20 L20 80 M50 5 L50 95 M5 50 L95 50" 
              stroke="white" 
              strokeWidth="0.3" 
            />
          </svg>
        </div>
        
        <div className="relative z-10 flex items-baseline justify-center font-black font-headline text-3xl tracking-tighter text-white drop-shadow-xl">
          <span className="relative">A</span>
          <span className="-ml-0.5 relative flex items-center">
            B
          </span>
        </div>
      </div>

      {/* Unique Brand Typography with Different Colors */}
      <div className="flex flex-col items-center space-y-0.5 text-center">
        <h2 className="text-[12px] font-black font-headline tracking-[0.25em] text-[#135890] uppercase leading-none">
          IT SUPPORT
        </h2>
        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#f97316] leading-none">
          SOLUTATION
        </span>
        <div className="flex items-center gap-1.5 pt-0.5">
          <span className="text-[11px] font-black text-slate-900 uppercase tracking-tight">
            AB IT
          </span>
          <span className="text-[12px] font-black text-[#dc2626] italic tracking-[0.15em] drop-shadow-sm">
            PRO
          </span>
        </div>
      </div>
    </div>
  );
}
