
"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from 'next/navigation';
import { 
  Building,
  Mail,
  Phone,
  User as UserIcon,
  Hash,
  Activity,
  Calendar,
  LogOut,
  Save,
  PlusCircle,
  Monitor,
  Cpu,
  Search,
  Settings,
  Bell,
  Eye,
  Pencil,
  Trash2,
  ArrowLeft,
  Info,
  MapPin,
  Banknote,
  Receipt,
  FileText,
  Database,
  Plus,
  Users,
  MessageSquare,
  ChevronRight,
  Clock,
  ShieldAlert,
  ShieldCheck,
  Lock,
  Globe,
  Server,
  Key,
  GlobeLock,
  LayoutGrid,
  History,
  HardDrive,
  BarChart3,
  Wifi,
  Zap,
  Fingerprint,
  Video,
  Network as NetworkIcon,
  Shield,
  Smartphone,
  Router,
  FlameKindling,
  Crosshair,
  Radar,
  Cloud,
  Layers,
  ShieldQuestion,
  Wrench,
  Terminal,
  Code,
  Workflow,
  CheckCircle2,
  Trophy,
  Briefcase,
  GraduationCap,
  UserPlus,
  HelpCircle,
  BookOpen,
  Laptop
} from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Logo } from "@/components/logo";
import { DatePicker } from "@/components/ui/date-picker";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { SidebarProvider, Sidebar, SidebarTrigger, SidebarContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset, SidebarHeader, SidebarFooter } from "@/components/ui/sidebar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const initialClientState = {
  clientId: "",
  name: "",
  category: "",
  setupDate: undefined as Date | undefined,
  contactPerson: "",
  email: "",
  contact: "",
  address: "",
};

const initialTechnicianState = {
  name: "",
  id: "",
  address: "",
  email: "",
  contact: "",
  role: "",
  salary: "",
  joiningDate: undefined as Date | undefined,
};

const initialStockState = {
  id: "", 
  clientName: "",
  address: "",
  vatNo: "",
  issueDate: undefined as Date | undefined,
  paymentMode: "",
  sn: "1",
  hsCode: "",
  name: "", 
  qty: "",
  rate: "",
  amount: "0.00",
  items: [] as any[],
  subTotal: "0.00",
  discount: "0",
  taxableAmount: "0.00",
  vat: "0.00",
  grandTotal: "0.00",
};

const initialWorkLogEntry = {
  sn: "",
  location: "",
  particular: "",
  time: "",
};

const defaultSettings = {
  siteName: "AB IT SOLUTATION PRO",
  tagline: "Enterprise Computer Hardware & Network Solutions",
  copyright: "Criginal AB IT SUPPORT | Powered by Enterprise Systems",
  language: "en",
  timezone: "NPT",
  adminEmail: "tharubishnu110@gmail.com",
  firewallEnabled: true,
  rateLimiting: true,
  ipAddress: "192.168.1.1",
  subnetMask: "255.255.255.0",
  gateway: "192.168.1.254",
  dnsServer: "8.8.8.8, 8.8.4.4",
  ipType: "Static",
};

const SetupGuide = () => (
  <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="text-center space-y-2">
      <h2 className="text-3xl font-black font-headline text-black">How to Setup in This Website (Step by Step)</h2>
      <p className="text-muted-foreground font-medium text-black">Follow these simple steps to get your enterprise infrastructure managed.</p>
    </div>

    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[
        { step: 1, title: "Go to the Website", desc: "Open your browser and visit the official portal URL to begin.", icon: Globe },
        { step: 2, title: "Click on Sign Up", desc: "Locate and click the 'SIGN UP' button in the top navigation bar.", icon: UserPlus },
        { step: 3, title: "Create Your Account", desc: "Enter your full name, email, and establish a high-security password.", icon: FileText },
        { step: 4, title: "Verify Your Email", desc: "Check your inbox for a verification link to activate your managed profile.", icon: Mail },
        { step: 5, title: "Login to Your Account", desc: "Use your verified credentials to access the secure enterprise portal.", icon: Lock },
        { step: 6, title: "Go to Dashboard", desc: "Upon entry, you will be redirected to your centralized management hub.", icon: LayoutGrid },
        { step: 7, title: "Add Your Server", desc: "Navigate to Servers > Add Server to register your first infrastructure node.", icon: Server },
        { step: 8, title: "Monitor Your Server", desc: "Access the Monitoring panel to view real-time telemetry and health data.", icon: Activity },
        { step: 9, title: "Setup Backup", desc: "Configure automated backup routines to ensure maximum data redundancy.", icon: Database },
      ].map((item) => (
        <Card key={item.step} className="border-none shadow-xl overflow-hidden group hover:ring-2 hover:ring-primary/20 transition-all">
          <div className="bg-[#135890] px-4 py-2 flex items-center gap-3">
             <div className="h-6 w-6 rounded-full bg-white flex items-center justify-center text-[#135890] font-black text-xs">
               {item.step}
             </div>
             <h3 className="text-white text-[10px] font-black uppercase tracking-widest">{item.title}</h3>
          </div>
          <CardContent className="p-6 space-y-4">
             <div className="aspect-video bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center relative overflow-hidden">
                <item.icon className="h-12 w-12 text-[#135890]/20 group-hover:scale-110 transition-transform" />
             </div>
             <p className="text-sm font-black text-black leading-relaxed">{item.desc}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

export default function DashboardPage() {
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [isMounted, setIsMounted] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  
  const isAdmin = auth.accountDetails?.user === 'Bishnu';
  
  const [activeTab, setActiveTab] = useState(isAdmin ? "client-profile" : "my-profile");
  const [clientViewMode, setClientViewMode] = useState<'list' | 'form'>(isAdmin ? 'list' : 'form');
  
  const [client, setClient] = useState(initialClientState);
  const [technician, setTechnician] = useState(initialTechnicianState);
  const [stock, setStock] = useState(initialStockState);
  const [newWorkLog, setNewWorkLog] = useState(initialWorkLogEntry);
  const [settings, setSettings] = useState(defaultSettings);
  const [localData, setLocalData] = useState<any[]>([]);
  const [workLogs, setWorkLogs] = useState<any[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [searchFilters, setSearchFilters] = useState({ name: '', id: '' });
  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  useEffect(() => {
    setIsMounted(true);
    setIsOnline(typeof navigator !== 'undefined' ? navigator.onLine : true);
    
    const saved = localStorage.getItem('dashboardRecords');
    if (saved) setLocalData(JSON.parse(saved));

    const savedLogs = localStorage.getItem('workLogs');
    if (savedLogs) setWorkLogs(JSON.parse(savedLogs));

    return () => {};
  }, []);

  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('dashboardRecords', JSON.stringify(localData));
      localStorage.setItem('workLogs', JSON.stringify(workLogs));
    }
  }, [localData, workLogs, isMounted]);

  useEffect(() => {
    if (isMounted && !auth.isAuthenticated) {
      router.replace('/login');
    }
  }, [auth.isAuthenticated, router, isMounted]);

  const handleInputChange = (setter: any) => (e: any) => {
    const { name, value, type, checked } = e.target;
    const val = type === 'checkbox' ? checked : value;
    setter((prev: any) => ({ ...prev, [name]: val }));
  };

  const handleSaveWorkLog = () => {
    if (!newWorkLog.location || !newWorkLog.particular) {
      toast({ variant: 'destructive', title: 'Error', description: 'Location and Particular are required.' });
      return;
    }
    const entry = {
      ...newWorkLog,
      sn: newWorkLog.sn || (workLogs.length + 1).toString(),
      time: newWorkLog.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setWorkLogs(prev => [...prev, entry]);
    setNewWorkLog(initialWorkLogEntry);
    toast({ title: "Work Log Saved", description: "Technical operation has been recorded." });
  };

  const handleDeleteWorkLog = (index: number) => {
    setWorkLogs(prev => prev.filter((_, i) => i !== index));
    toast({ variant: 'destructive', title: "Log Entry Deleted" });
  };

  const allData = useMemo(() => {
    if (!isMounted) return [];
    const registeredUsers = auth.getAllUsers().map(u => ({
      ...u,
      id: u.user,
      name: u.organizationName || u.user,
      type: 'registration',
      displayType: 'Registered User'
    }));
    const mappedLocal = localData.map(item => ({
      ...item,
      displayType: item.type === 'client' ? 'Client Profile' : item.type === 'stock' ? 'Invoice' : 'Staff Profile'
    }));
    return [...registeredUsers, ...mappedLocal];
  }, [localData, auth, isMounted]);

  if (!isMounted || !auth.isAuthenticated) return null;

  return (
    <SidebarProvider>
      <Sidebar className="border-r border-white/10 bg-card/80 backdrop-blur-xl">
        <SidebarHeader className="p-4"><Logo /></SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={() => setActiveTab(isAdmin ? 'client-profile' : 'my-profile')} isActive={activeTab === 'client-profile' || activeTab === 'my-profile'}>
                {isAdmin ? <Users /> : <UserIcon />} <span>{isAdmin ? 'Managed Clients' : 'My Client Account'}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={() => setActiveTab('work-logs')} isActive={activeTab === 'work-logs'}>
                <History /> <span>Work Logs</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={() => setActiveTab('server-mgmt')} isActive={activeTab === 'server-mgmt'}>
                <Server /> <span>Server Management</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={() => setActiveTab('setup-guide')} isActive={activeTab === 'setup-guide'}>
                <BookOpen /> <span>Setup Guide</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="p-4 border-t border-white/10">
          <Button variant="ghost" className="w-full justify-start text-destructive" onClick={() => auth.logout()}>
            <LogOut className="mr-2 h-4 w-4" /> Logout
          </Button>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="bg-background relative overflow-hidden">
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-white/10 bg-background/80 backdrop-blur-md px-6">
          <div className="flex items-center">
            <SidebarTrigger />
            <h1 className="ml-4 text-sm font-black uppercase tracking-widest text-primary">
              {activeTab.replace('-', ' ')}
            </h1>
          </div>
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2">
                <Laptop className="h-4 w-4 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Local Host Optimization</span>
             </div>
          </div>
        </header>

        <main className="p-6 md:p-10 max-w-7xl mx-auto w-full space-y-8">
          {activeTab === 'setup-guide' && <SetupGuide />}
          
          {activeTab === 'work-logs' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle className="font-headline text-primary flex items-center gap-2">
                    <History className="h-6 w-6" /> Managed Work Logs
                  </CardTitle>
                  <CardDescription className="text-black font-medium">Add and manage technical service records manually.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Manual Entry Form */}
                  <div className="grid md:grid-cols-4 gap-4 items-end bg-slate-50 p-6 rounded-xl border border-slate-100">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-black">Sn</Label>
                      <Input name="sn" placeholder="e.g. 1" value={newWorkLog.sn} onChange={handleInputChange(setNewWorkLog)} className="bg-white text-black font-bold" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-black">Location</Label>
                      <Input name="location" placeholder="e.g. Server Room" value={newWorkLog.location} onChange={handleInputChange(setNewWorkLog)} className="bg-white text-black font-bold" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-black">Particular</Label>
                      <Input name="particular" placeholder="e.g. Maintenance" value={newWorkLog.particular} onChange={handleInputChange(setNewWorkLog)} className="bg-white text-black font-bold" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] font-black uppercase text-black">Time</Label>
                      <div className="flex gap-2">
                        <Input name="time" placeholder="10:00 AM" value={newWorkLog.time} onChange={handleInputChange(setNewWorkLog)} className="bg-white text-black font-bold" />
                        <Button onClick={handleSaveWorkLog} className="bg-primary hover:bg-primary/90 text-white font-bold">
                          <Save className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Working Table */}
                  <div className="rounded-xl border border-black/10 overflow-hidden bg-white shadow-sm">
                    <Table>
                      <TableHeader className="bg-slate-100">
                        <TableRow className="border-black/10">
                          <TableHead className="text-black font-black uppercase text-[10px] w-16">Sn</TableHead>
                          <TableHead className="text-black font-black uppercase text-[10px]">Location</TableHead>
                          <TableHead className="text-black font-black uppercase text-[10px]">Particular</TableHead>
                          <TableHead className="text-black font-black uppercase text-[10px]">Time</TableHead>
                          <TableHead className="text-right text-black font-black uppercase text-[10px] w-20">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {workLogs.length > 0 ? (
                          workLogs.map((log, i) => (
                            <TableRow key={i} className="border-black/5">
                              <TableCell className="font-black text-black">{log.sn}</TableCell>
                              <TableCell className="font-bold text-black">{log.location}</TableCell>
                              <TableCell className="text-black font-medium">{log.particular}</TableCell>
                              <TableCell className="text-black font-mono text-xs font-black">{log.time}</TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteWorkLog(i)} className="h-8 w-8 text-destructive">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-20 opacity-30 italic text-black">No technical logs recorded.</TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'server-mgmt' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-black font-headline text-black flex items-center gap-2">
                  <Layers className="text-primary h-8 w-8" /> MSP Server Management
                </h2>
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 px-4 py-1 text-[10px] font-black uppercase tracking-widest">
                  Enterprise Infrastructure
                </Badge>
              </div>

              <Tabs defaultValue="ops" className="w-full">
                <TabsList className="bg-white/5 border border-white/10 p-1 mb-6 flex-wrap h-auto">
                  <TabsTrigger value="ops" className="data-[state=active]:bg-primary data-[state=active]:text-white font-black">Core Ops</TabsTrigger>
                  <TabsTrigger value="infra" className="data-[state=active]:bg-primary data-[state=active]:text-white font-black">Infra Registry</TabsTrigger>
                  <TabsTrigger value="automation" className="data-[state=active]:bg-primary data-[state=active]:text-white font-black">Automation</TabsTrigger>
                </TabsList>

                <TabsContent value="ops" className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    { title: "1. Monitoring", items: ["CPU Usage", "RAM Usage", "Disk Space", "Network Traffic", "Uptime", "Hardware Health"] },
                    { title: "2. Access Mgmt", items: ["User Create/Delete", "Password Reset", "Permissions", "Active Directory", "RBAC"] },
                    { title: "3. Security", items: ["Firewall", "Antivirus", "Intrusion Detection", "Patch Mgmt", "MFA", "VPN"] },
                    { title: "4. Backup", items: ["Daily/Weekly", "Cloud Backup", "Incremental", "Restore Test", "Disaster Recovery"] },
                    { title: "5. Maintenance", items: ["OS Updates", "Driver Updates", "Firmware", "Optimization", "Log Cleanup"] }
                  ].map((cat, i) => (
                    <Card key={i} className="bg-white shadow-xl border-none">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-black uppercase text-primary">{cat.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-1">
                          {cat.items.map((it, idx) => (
                            <li key={idx} className="text-xs font-bold text-black flex items-center gap-2">
                               <div className="h-1 w-1 bg-primary rounded-full" /> {it}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="infra" className="space-y-6">
                  <Card className="bg-white shadow-xl border-none">
                    <CardHeader><CardTitle className="text-lg font-black uppercase text-primary">Managed Server Registry</CardTitle></CardHeader>
                    <CardContent>
                       <Table>
                         <TableHeader><TableRow><TableHead className="text-black font-black">Server Type</TableHead><TableHead className="text-black font-black">Purpose</TableHead></TableRow></TableHeader>
                         <TableBody>
                           {[
                             {t: "File Server", p: "File Sharing"},
                             {t: "Web Server", p: "Hosting"},
                             {t: "Database Server", p: "MySQL, SQL"},
                             {t: "Mail Server", p: "Email Service"},
                             {t: "DNS Server", p: "Resolution"},
                             {t: "DHCP Server", p: "IP Distribution"}
                           ].map((r, i) => (
                             <TableRow key={i}><TableCell className="font-black text-black">{r.t}</TableCell><TableCell className="text-black font-medium">{r.p}</TableCell></TableRow>
                           ))}
                         </TableBody>
                       </Table>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="automation" className="space-y-6">
                   <Card className="bg-black text-white font-mono p-6 rounded-xl shadow-2xl overflow-hidden border border-white/10">
                     <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-2">
                        <Terminal className="h-4 w-4 text-primary" />
                        <span className="text-[10px] font-black uppercase">Automation Scripts</span>
                     </div>
                     <pre className="text-xs text-blue-300">
                       <code>{`# PowerShell Health Check
Get-Process | Sort CPU -Descending | Select -First 10

# Python Ping Automation
import os
servers = ["192.168.1.1", "192.168.1.2"]
for s in servers:
    if os.system(f"ping -n 1 {s}") == 0:
        print(f"{s} UP")`}</code>
                     </pre>
                   </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {(activeTab === 'client-profile' || activeTab === 'my-profile') && (
            <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
               <CardHeader><CardTitle className="font-headline text-primary">Managed Profiles</CardTitle></CardHeader>
               <CardContent>
                  <p className="text-black font-black opacity-50 italic">Centralized infrastructure accounts managed by local server registry.</p>
               </CardContent>
            </Card>
          )}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
