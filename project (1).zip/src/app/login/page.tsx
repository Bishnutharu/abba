
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Lock, User, ArrowRight, ShieldCheck, UserPlus, Eye, EyeOff, HelpCircle } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    router.prefetch('/dashboard');
    router.prefetch('/register');
    router.prefetch('/forgot-password');
  }, [router]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const result = login(username, password);

    if (result === 'SUCCESS') {
      toast({ title: "Authorized Access", description: "Opening your registered client account..." });
    } else if (result === 'NOT_REGISTERED') {
      toast({ 
        variant: "destructive", 
        title: "Account Not Found", 
        description: "This account is not registered in our system. Please use a registered client account." 
      });
      setIsLoading(false);
    } else {
      toast({ 
        variant: "destructive", 
        title: "Access Denied", 
        description: "Invalid credentials. Please verify your registered account details." 
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-hidden px-4">
      {/* Dynamic Background Elements */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-md relative z-10 space-y-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <Logo className="scale-125 mb-4" />
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight text-white font-headline">Client Account Portal</h1>
            <p className="text-muted-foreground font-medium">Securely access your registered enterprise profile.</p>
          </div>
        </div>

        <Card className="border-white/10 bg-card/50 backdrop-blur-xl shadow-2xl">
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-between mb-2">
               <CardTitle className="text-xl flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" /> Client Login
              </CardTitle>
              <Badge variant="outline" className="border-primary/50 text-[10px] font-black uppercase text-primary tracking-widest">
                Registered Access Only
              </Badge>
            </div>
            <CardDescription>
              Enter your registered username and password to continue.
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-xs font-black uppercase tracking-widest text-muted-foreground">Registered Username</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="username" 
                    placeholder="Enter username" 
                    className="pl-10 bg-background/50 border-white/10 focus:border-primary h-12" 
                    required 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-xs font-black uppercase tracking-widest text-muted-foreground">Secret Password</Label>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="password" 
                    type={showPassword ? "text" : "password"} 
                    placeholder="••••••••" 
                    className="pl-10 pr-10 bg-background/50 border-white/10 focus:border-primary h-12" 
                    required 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-muted-foreground hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full font-black h-12 text-base bg-primary hover:bg-primary/90" disabled={isLoading}>
                {isLoading ? "Validating Registry..." : "Access Client Account"} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <div className="grid grid-cols-2 gap-4 w-full">
                <Button variant="outline" asChild className="border-white/10 hover:bg-white/5 font-black text-xs">
                  <Link href="/register">
                    <UserPlus className="mr-2 h-4 w-4" /> New Client
                  </Link>
                </Button>
                <Button variant="ghost" asChild className="hover:bg-primary/10 font-black text-xs text-primary">
                  <Link href="/forgot-password">
                    <HelpCircle className="mr-2 h-4 w-4" /> Forgot?
                  </Link>
                </Button>
              </div>
            </CardFooter>
          </form>
        </Card>

        <p className="text-center text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">
          Criginal AB IT SUPPORT | Powered by Enterprise Systems
        </p>
      </div>
    </div>
  );
}
