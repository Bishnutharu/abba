
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Mail, ShieldCheck, ArrowRight, ArrowLeft, Key, Lock, CheckCircle2, Loader2 } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";

export default function ForgotPasswordPage() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [identifier, setIdentifier] = useState("");
  const [code, setCode] = useState("");
  const [newPass, setNewPass] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [simulatedCode, setSimulatedCode] = useState("");
  
  const { sendPasswordResetCode, resetPassword } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate high-speed automated processing
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const result = sendPasswordResetCode(identifier);
    if (result.success) {
      toast({ 
        title: "Code Dispatched", 
        description: `An encrypted recovery code was sent to the registry associated with ${identifier}.` 
      });
      setSimulatedCode(result.code || ""); 
      setStep(2);
    } else {
      toast({ 
        variant: "destructive", 
        title: "Recovery Error", 
        description: result.message 
      });
    }
    setIsLoading(false);
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === simulatedCode) {
      setStep(3);
    } else {
      toast({ 
        variant: "destructive", 
        title: "Invalid Code", 
        description: "The verification code provided does not match our records." 
      });
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const result = resetPassword(identifier, code, newPass);
    if (result === 'SUCCESS') {
      toast({ 
        title: "Profile Restored", 
        description: "Your enterprise password has been updated. Redirecting to login..." 
      });
      setTimeout(() => router.push("/login"), 1500);
    } else {
      toast({ 
        variant: "destructive", 
        title: "Update Failed", 
        description: "Could not apply the new security policy. Please try again." 
      });
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-hidden px-4">
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-md relative z-10 space-y-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <Logo className="scale-110" />
          <h1 className="text-3xl font-bold tracking-tight text-white font-headline">Account Recovery</h1>
        </div>

        <Card className="border-white/10 bg-card/50 backdrop-blur-xl shadow-2xl">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-[10px] font-black ${step >= 1 ? 'bg-primary text-white shadow-[0_0_10px_rgba(59,130,246,0.5)]' : 'bg-white/10 text-white/40'}`}>1</div>
              <div className={cn("h-px flex-1 transition-colors duration-500", step >= 2 ? "bg-primary" : "bg-white/10")} />
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-[10px] font-black ${step >= 2 ? 'bg-primary text-white shadow-[0_0_10px_rgba(59,130,246,0.5)]' : 'bg-white/10 text-white/40'}`}>2</div>
              <div className={cn("h-px flex-1 transition-colors duration-500", step >= 3 ? "bg-primary" : "bg-white/10")} />
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-[10px] font-black ${step >= 3 ? 'bg-primary text-white shadow-[0_0_10px_rgba(59,130,246,0.5)]' : 'bg-white/10 text-white/40'}`}>3</div>
            </div>
            <CardTitle className="text-xl flex items-center gap-2 font-headline">
              {step === 1 && <Mail className="h-5 w-5 text-primary" />}
              {step === 2 && <Key className="h-5 w-5 text-primary" />}
              {step === 3 && <Lock className="h-5 w-5 text-primary" />}
              {step === 1 ? 'Identify Managed Account' : step === 2 ? 'Security Verification' : 'Update Security Policy'}
            </CardTitle>
            <CardDescription className="text-xs">
              {step === 1 && 'Provide your infrastructure ID or work email to generate a recovery code.'}
              {step === 2 && `We've dispatched a 6-digit code. Please verify to continue.`}
              {step === 3 && 'Establish a new high-security password for your corporate profile.'}
            </CardDescription>
          </CardHeader>

          {step === 1 && (
            <form onSubmit={handleSendCode}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="id" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Username or Work Email</Label>
                  <Input 
                    id="id" 
                    placeholder="e.g., email/number" 
                    className="bg-background/50 border-white/10 focus:border-primary h-12" 
                    required 
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4 pt-2">
                <Button type="submit" className="w-full font-bold h-12 bg-primary hover:bg-primary/90" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Dispatching Code...
                    </>
                  ) : (
                    <>
                      Send Recovery Code <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
                <Button variant="ghost" asChild className="w-full text-xs text-muted-foreground hover:text-white">
                  <Link href="/login"><ArrowLeft className="mr-2 h-4 w-4" /> Return to Secure Portal</Link>
                </Button>
              </CardFooter>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleVerifyCode}>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-accent/10 border border-accent/20 flex items-center gap-4 animate-pulse">
                    <CheckCircle2 className="h-6 w-6 text-accent" />
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-accent mb-0.5">Automated Dispatcher</p>
                      <p className="text-sm font-medium text-white/90">Your verification code: <span className="font-mono text-white font-black bg-accent px-2 py-0.5 rounded ml-1">{simulatedCode}</span></p>
                    </div>
                  </div>
                  <div className="space-y-2 text-center">
                    <Label htmlFor="code" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Enter 6-Digit Code</Label>
                    <Input 
                      id="code" 
                      placeholder="XXXXXX" 
                      maxLength={6}
                      className="bg-background/50 border-white/10 focus:border-primary font-mono tracking-[0.8em] text-center text-2xl h-14" 
                      required 
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4 pt-2">
                <Button type="submit" className="w-full font-bold h-12 bg-accent hover:bg-accent/90">
                  Verify Identity <ShieldCheck className="ml-2 h-4 w-4" />
                </Button>
                <button 
                  type="button" 
                  onClick={() => setStep(1)} 
                  className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors"
                >
                  Didn't receive code? Change ID or Resend
                </button>
              </CardFooter>
            </form>
          )}

          {step === 3 && (
            <form onSubmit={handleResetPassword}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newPass" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">New Secure Password</Label>
                  <Input 
                    id="newPass" 
                    type="password"
                    placeholder="••••••••" 
                    className="bg-background/50 border-white/10 focus:border-primary h-12" 
                    required 
                    value={newPass}
                    onChange={(e) => setNewPass(e.target.value)}
                  />
                  <p className="text-[10px] text-muted-foreground italic">Use at least 8 characters with a mix of letters and numbers.</p>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4 pt-2">
                <Button type="submit" className="w-full font-bold h-12 bg-primary hover:bg-primary/90" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Updating Policy...
                    </>
                  ) : (
                    <>
                      Apply New Password <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
