"use client";

import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Network, 
  Monitor, 
  Phone,
  Wrench,
  ChevronDown,
  ShieldCheck,
  CheckCircle2,
  Zap,
  Star,
  Video,
  Headset,
  Facebook,
  Instagram,
  Mail,
  MapPin
} from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";

export default function HomePage() {
  const { toast } = useToast();

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const firstName = formData.get('firstName') as string;
    const lastName = formData.get('lastName') as string;
    const phone = formData.get('phone') as string;
    const email = formData.get('email') as string;
    const message = formData.get('message') as string;

    const newRequest = {
      id: `REQ-${Date.now()}`,
      clientId: `CLI-${Date.now()}`,
      type: 'client',
      name: `${firstName} ${lastName}`,
      email,
      contact: phone,
      message,
      category: 'Contact Request',
      isNew: true,
      setupDate: new Date().toISOString(),
      address: 'Inquiry from Homepage'
    };

    // Persistence layer: shared with Dashboard
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('dashboardRecords');
      const records = saved ? JSON.parse(saved) : [];
      records.push(newRequest);
      localStorage.setItem('dashboardRecords', JSON.stringify(records));
    }

    toast({
      title: "Request Received",
      description: "Our technical team will contact you shortly.",
    });

    form.reset();
  };

  const getImg = (id: string) => PlaceHolderImages.find(img => img.id === id)?.imageUrl || null;

  return (
    <div className="flex flex-col min-h-screen bg-white text-[#0f172a] font-body">
      {/* Top Bar */}
      <div className="bg-[#0f172a] text-white py-2 text-[10px] font-bold px-6 border-b border-white/5">
        <div className="container mx-auto flex justify-between items-center">
          <span className="opacity-70 tracking-widest uppercase">Computer Hardware & Network Technician Service</span>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2 font-mono"><Phone className="h-3 w-3 text-primary" /> +977 9822533548</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur-md shadow-sm">
        <div className="container mx-auto flex h-20 items-center justify-between px-6">
          <Logo />
          <nav className="hidden lg:flex items-center gap-8 text-[12px] font-bold uppercase tracking-widest opacity-80">
            <div className="flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
              Services <ChevronDown className="h-3 w-3" />
            </div>
            <Link href="#" className="hover:text-primary transition-colors">About</Link>
            <Link href="#" className="hover:text-primary transition-colors">Portfolio</Link>
            <Link href="#" className="hover:text-primary transition-colors">Contact</Link>
            <Link href="/support" className="hover:text-primary transition-colors">24/7 Support</Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button asChild className="bg-[#f97316] hover:bg-[#ea580c] text-white font-bold rounded-md px-8 h-12">
              <Link href="/login">Client Portal</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden min-h-[600px] flex items-center bg-[#0f172a]">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#1e293b] to-[#0f172a] z-10 opacity-50" />
            <div className="absolute top-0 right-0 w-[50%] h-full bg-primary/5 blur-[120px] rounded-full translate-x-1/2" />
          </div>

          <div className="container mx-auto px-6 relative z-20">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-700">
                <h1 className="text-5xl md:text-6xl font-black text-white font-headline leading-[1.1]">
                  Professional <br/>
                  Computer Hardware & <br/>
                  Network Technician <br/>
                  <span className="text-primary">AB IT </span><sup className="text-red-600 italic text-2xl font-black">PRO</sup>
                </h1>
                <p className="text-xl text-white/70 max-w-lg leading-relaxed font-medium">
                  Expert Technician Services for Homes & Businesses — Upgrades, Repairs, Network Setup, & Support.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button className="bg-primary hover:bg-primary/90 text-white font-bold h-14 px-10 rounded-md text-lg shadow-lg shadow-primary/20">
                    Get a Free Quote
                  </Button>
                  <Button variant="outline" className="bg-[#f97316] hover:bg-[#ea580c] border-[#f97316] text-white font-bold h-14 px-10 rounded-md text-lg">
                    Schedule Service
                  </Button>
                </div>
              </div>
              <div className="hidden lg:block animate-in fade-in zoom-in-95 duration-700 delay-300">
                <div className="relative p-1 bg-white/5 rounded-2xl border border-white/10 overflow-hidden backdrop-blur-sm">
                   <div className="aspect-[4/3] bg-[#1e293b] rounded-xl flex items-center justify-center relative overflow-hidden">
                      {getImg('technician-hero') ? (
                        <Image 
                          src={getImg('technician-hero')!} 
                          alt="Infrastructure Management" 
                          fill
                          className="object-cover opacity-80"
                          data-ai-hint="it technician"
                        />
                      ) : (
                        <Monitor className="h-32 w-32 text-primary opacity-20" />
                      )}
                   </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16 space-y-4">
              <h2 className="text-4xl font-black font-headline">Our Services</h2>
              <div className="w-20 h-1.5 bg-primary mx-auto rounded-full" />
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
              {[
                { title: "Hardware Repair", icon: Wrench },
                { title: "Network Setup", icon: Network },
                { title: "IT Support", icon: Headset },
                { title: "Surveillance", icon: Video },
                { title: "Security Audit", icon: ShieldCheck }
              ].map((service, i) => (
                <div key={i} className="flex flex-col items-center group cursor-pointer">
                  <div className="h-20 w-20 rounded-2xl bg-[#f1f5f9] flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-all duration-300 shadow-sm">
                    <service.icon className="h-10 w-10 text-primary group-hover:text-white" />
                  </div>
                  <h3 className="font-bold text-center text-sm uppercase tracking-widest">{service.title}</h3>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Success Stories */}
        <section className="py-24 bg-[#f8fafc]">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16 space-y-2">
              <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs">Client Testimonials</p>
              <h2 className="text-4xl font-black font-headline">Service Excellence</h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { name: "Anita Chaudhary", role: "CEO, TechFlow", text: "Professional and managing is my client, teaching and better and things are also excellence above all I am satisfied.", img: "https://picsum.photos/seed/a1/100/100" },
                { name: "Bishnu Tharu", role: "IT Manager", text: "Happy client, newly coming every day and providing best service is the secret of your success with our IT challenges solved.", img: "https://picsum.photos/seed/a2/100/100" },
                { name: "Ram Prasad Tharu", role: "Business Owner", text: "Magnificent and outstanding our business infrastructure. With your technical help we are reaching new levels.", img: "https://picsum.photos/seed/a3/100/100" },
              ].map((t, i) => (
                <Card key={i} className="border-none shadow-xl rounded-3xl overflow-hidden bg-white hover:-translate-y-2 transition-transform duration-300">
                  <CardContent className="p-10 flex flex-col items-center text-center space-y-6">
                    <img src={t.img} alt={t.name} className="h-24 w-24 rounded-full border-4 border-primary/10" />
                    <p className="text-slate-600 italic leading-relaxed">"{t.text}"</p>
                    <div>
                      <h4 className="font-black text-lg">{t.name}</h4>
                      <p className="text-[10px] text-primary font-bold uppercase tracking-[0.2em]">{t.role}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Values and Contact */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-6">
            <div className="grid lg:grid-cols-12 gap-16 items-start">
              <div className="lg:col-span-7 space-y-12">
                <div className="space-y-4">
                  <h2 className="text-4xl font-black font-headline">Why Choose AB IT SOLUTATION PRO?</h2>
                  <div className="w-16 h-1 bg-primary" />
                </div>
                
                <div className="grid sm:grid-cols-2 gap-8">
                  {[
                    { title: "Expertise", text: "Years of experience in enterprise hardware and networking.", icon: CheckCircle2 },
                    { title: "Reliability", text: "Guaranteed uptime and responsive infrastructure support.", icon: ShieldCheck },
                    { title: "Fast Response", text: "Priority support for critical system failures.", icon: Zap },
                    { title: "Certified Techs", text: "Engineers trained in the latest security standards.", icon: Star },
                  ].map((value, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <value.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-bold mb-1">{value.title}</h4>
                        <p className="text-xs text-slate-500 leading-relaxed">{value.text}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-6 pt-8 border-t border-slate-100">
                  <h3 className="text-2xl font-black font-headline">Latest Projects</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      { title: "Surveillance NVR Center", img: getImg('project-cctv'), hint: "cctv monitor" },
                      { title: "Enterprise Server Rack", img: getImg('project-network'), hint: "server rack" },
                      { title: "Managed Hardware Diagnostics", img: getImg('project-hardware'), hint: "computer hardware" },
                    ].map((p, i) => (
                      <div key={i} className="group flex flex-col space-y-3">
                        <div className="aspect-video rounded-2xl overflow-hidden shadow-xl border border-slate-100 relative bg-slate-100">
                          {p.img ? (
                            <img 
                              src={p.img} 
                              alt={p.title} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                              data-ai-hint={p.hint} 
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Monitor className="h-8 w-8 text-slate-300" />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                            <span className="text-white text-[10px] font-bold uppercase tracking-widest">View Case Study</span>
                          </div>
                        </div>
                        <h4 className="font-black text-sm uppercase tracking-wide group-hover:text-primary transition-colors">{p.title}</h4>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5">
                <Card className="bg-[#0f172a] border-none text-white rounded-[2rem] overflow-hidden shadow-2xl">
                  <CardHeader className="p-10 pb-0">
                    <CardTitle className="text-3xl font-black font-headline">Contact</CardTitle>
                    <p className="text-white/50 text-sm">Request a technical site survey today.</p>
                  </CardHeader>
                  <CardContent className="p-10 pt-6">
                    <form onSubmit={handleContactSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <Input name="firstName" placeholder="First Name" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-12" required />
                        <Input name="lastName" placeholder="Last Name" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-12" required />
                      </div>
                      <Input name="phone" placeholder="Phone" type="tel" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-12" required />
                      <Input name="email" placeholder="Email" type="email" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-12" required />
                      <Textarea name="message" placeholder="How can we help?" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 min-h-[120px]" required />
                      <Button type="submit" className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-bold h-14 rounded-xl text-lg mt-4">
                        Submit Request
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white py-20 border-t border-white/5">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-12 mb-20">
            <div className="col-span-2 md:col-span-1 space-y-8">
              <Logo className="brightness-0 invert scale-110" />
              <p className="text-white/40 text-xs leading-relaxed font-medium">
                Professional enterprise hardware and network solutions provider. Excellence in infrastructure for modern businesses.
              </p>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-white/90">Company</h4>
              <ul className="space-y-4 text-xs text-white/40 font-bold">
                <li><Link href="#" className="hover:text-primary transition-colors">Our Services</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">About Us</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Case Studies</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-white/90">Services</h4>
              <ul className="space-y-4 text-xs text-white/40 font-bold">
                <li><Link href="#" className="hover:text-primary transition-colors">Hardware Repair</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Network Setup</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Security Audit</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">CCTV Solutions</Link></li>
              </ul>
            </div>
            {/* Location Section - Left of Connect */}
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-white/90">Location</h4>
              <Link 
                href="https://www.google.com/maps/place/Nepalgunj/@28.0678325,81.6294479,12z/data=!3m1!4b1!4m6!3m5!1s0x3998675a30f8e175:0x93c04013828c9891!8m2!3d28.053906!4d81.6159241!16s%2Fm%2F025tfqc?entry=ttu&g_ep=EgoyMDI2MDUxMy4wIKXMDSoASAFQAw%3D%3D"
                target="_blank"
                className="flex items-start gap-3 text-xs text-white/40 font-bold hover:text-primary transition-colors group"
              >
                <MapPin className="h-4 w-4 text-primary shrink-0 group-hover:scale-110 transition-transform" />
                <p>Nepalgunj, Banke, Nepal</p>
              </Link>
            </div>
            {/* Connect Section */}
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-white/90">Connect</h4>
              <div className="flex gap-4">
                <Link href="https://www.facebook.com/" target="_blank" className="h-10 w-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary transition-all cursor-pointer group">
                  <Facebook className="h-4 w-4 group-hover:text-white" />
                </Link>
                <Link href="https://www.instagram.com/" target="_blank" className="h-10 w-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary transition-all cursor-pointer group">
                  <Instagram className="h-4 w-4 group-hover:text-white" />
                </Link>
                <Link href="mailto:tharubishnu110@gmail.com" target="_blank" className="h-10 w-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary transition-all cursor-pointer group">
                  <Mail className="h-4 w-4 group-hover:text-white" />
                </Link>
                <Link href="https://web.whatsapp.com/" target="_blank" className="h-10 w-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary transition-all cursor-pointer group">
                  <svg
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="h-4 w-4 group-hover:text-white"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
          <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-[10px] text-white/20 font-bold uppercase tracking-[0.2em]">
              Criginal AB IT SUPPORT | Powered by Enterprise Systems
            </p>
            <div className="flex gap-8 text-[10px] text-white/20 font-bold uppercase tracking-[0.2em]">
              <Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link>
              <Link href="#" className="hover:text-white transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
