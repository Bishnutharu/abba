'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { checkLicense, activateLicense, LicenseInfo } from '@/lib/licensing';

export interface UpdatableAccountDetails {
  organizationName: string;
  address1: string;
  address2: string;
  phone: string;
  email: string;
  logo?: string;
}

export interface FullAccountDetails extends UpdatableAccountDetails {
  user: string;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  isAwaitingVerification: boolean;
  licenseInfo: LicenseInfo;
  devices: any[];
  accountDetails: FullAccountDetails | null;
  login: (user: string, pass: string) => 'SUCCESS' | 'NOT_REGISTERED' | 'INVALID_CREDENTIALS' | 'AWAITING_VERIFICATION';
  verifyLogin: (code: string) => 'SUCCESS' | 'INVALID_CODE';
  logout: () => void;
  logoutDevice: (deviceId: string) => void;
  activate: (key: string) => boolean;
  register: (details: FullAccountDetails & { pass: string }) => boolean;
  deleteUser: (user: string) => void;
  getAllUsers: () => (FullAccountDetails & { pass: string })[];
  sendPasswordResetCode: (userOrEmail: string) => { success: boolean; code?: string; message: string };
  resetPassword: (userOrEmail: string, code: string, newPass: string) => 'SUCCESS' | 'INVALID_CODE' | 'USER_NOT_FOUND';
  changePassword: (currentPass: string, newPass: string) => 'SUCCESS' | 'INVALID_PASSWORD';
  updateAccountDetails: (details: UpdatableAccountDetails) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAwaitingVerification, setIsAwaitingVerification] = useState(false);
  const [devices, setDevices] = useState<any[]>([]);
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo>({ status: null, daysRemaining: 0 });
  const [accountDetails, setAccountDetails] = useState<FullAccountDetails | null>(null);
  const [resetCodes, setResetCodes] = useState<Record<string, string>>({});
  const router = useRouter();

  const loadUserData = React.useCallback(() => {
    if (typeof window === 'undefined') return;
    const currentUserStr = localStorage.getItem('currentUser');
    if (currentUserStr) {
      try {
        const storedUser = JSON.parse(currentUserStr);
        setDevices(storedUser.devices || []);
        setAccountDetails({
          organizationName: storedUser.organizationName || "",
          address1: storedUser.address1 || "",
          address2: storedUser.address2 || "",
          phone: storedUser.phone || "",
          email: storedUser.email || "",
          user: storedUser.user || "",
          logo: storedUser.logo
        });
        return storedUser;
      } catch (e) {
        console.error("Failed to parse user data", e);
        return null;
      }
    }
    return null;
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const authState = localStorage.getItem('isAuthenticated');
    if (authState === 'true') {
      setIsAuthenticated(true);
      loadUserData();
    }

    setLicenseInfo(checkLicense());
  }, [loadUserData]);

  const getUsersFromStorage = React.useCallback((): any[] => {
    if (typeof window === 'undefined') return [];
    const usersStr = localStorage.getItem('appUsers');
    return usersStr ? JSON.parse(usersStr) : [];
  }, []);

  const login = (user: string, pass: string): 'SUCCESS' | 'NOT_REGISTERED' | 'INVALID_CREDENTIALS' | 'AWAITING_VERIFICATION' => {
    if (user === 'Bishnu' && pass === 'Bishnu@123') {
       const adminUser = {
         user: 'Bishnu',
         pass: 'Bishnu@123',
         organizationName: 'AB IT SUPPORT',
         email: 'tharubishnu110@gmail.com',
         phone: '9822533548',
         address1: 'Banke, Nepalgunj, Nepal',
         devices: []
       };
       localStorage.setItem('isAuthenticated', 'true');
       localStorage.setItem('currentUser', JSON.stringify(adminUser));
       setIsAuthenticated(true);
       setAccountDetails(adminUser);
       router.push('/dashboard');
       return 'SUCCESS';
    }

    const users = getUsersFromStorage();
    const foundUser = users.find(u => u.user === user || u.email === user);
    
    if (!foundUser) {
      return 'NOT_REGISTERED';
    }

    if (foundUser.pass === pass) {
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUser', JSON.stringify(foundUser));
        setIsAuthenticated(true);
        setAccountDetails(foundUser);
        setDevices(foundUser.devices || []);
        router.push('/dashboard');
        return 'SUCCESS';
    }
    return 'INVALID_CREDENTIALS';
  };

  const verifyLogin = (code: string): 'SUCCESS' | 'INVALID_CODE' => {
    return 'SUCCESS';
  };

  const logout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('currentUser');
    setIsAuthenticated(false);
    setDevices([]);
    setAccountDetails(null);
    router.push('/');
  };

  const logoutDevice = (deviceIdToLogout: string) => {
    // Mock
  };

  const activate = (key: string) => {
    const success = activateLicense(key);
    if (success) {
      setLicenseInfo(checkLicense());
    }
    return success;
  };

  const register = (details: FullAccountDetails & { pass: string }): boolean => {
    const { user, pass, email, phone } = details;
    if (user && pass && email && phone) {
      const users = getUsersFromStorage();
      const existing = users.findIndex(u => u.user === user);
      
      const newUser = { ...details, id: `USR-${Date.now()}`, devices: [] };
      if (existing >= 0) {
        users[existing] = newUser;
      } else {
        users.push(newUser);
      }
      
      localStorage.setItem('appUsers', JSON.stringify(users));
      return true;
    }
    return false;
  };

  const deleteUser = (username: string) => {
    const users = getUsersFromStorage();
    const updated = users.filter(u => u.user !== username);
    localStorage.setItem('appUsers', JSON.stringify(updated));
  };

  const getAllUsers = React.useCallback((): (FullAccountDetails & { pass: string })[] => {
    return getUsersFromStorage().map(u => ({
      user: u.user,
      pass: u.pass,
      organizationName: u.organizationName,
      email: u.email,
      phone: u.phone,
      address1: u.address1,
      address2: u.address2 || "",
      id: u.id
    })) as any;
  }, [getUsersFromStorage]);

  const sendPasswordResetCode = (userOrEmail: string): { success: boolean; code?: string; message: string } => {
    const users = getUsersFromStorage();
    const foundUser = users.find(u => u.user === userOrEmail || u.email === userOrEmail);
    
    if (!foundUser) {
      return { success: false, message: 'Account not found in technical registry.' };
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setResetCodes(prev => ({ ...prev, [userOrEmail]: code }));
    
    console.log(`[AB IT SUPPORT] Reset code for ${userOrEmail}: ${code}`);
    
    return { 
      success: true, 
      code,
      message: `Verification code sent to your registered contact method.` 
    };
  };

  const resetPassword = (userOrEmail: string, code: string, newPass: string): 'SUCCESS' | 'INVALID_CODE' | 'USER_NOT_FOUND' => {
    if (resetCodes[userOrEmail] !== code) {
      return 'INVALID_CODE';
    }

    const users = getUsersFromStorage();
    const index = users.findIndex(u => u.user === userOrEmail || u.email === userOrEmail);
    
    if (index === -1) return 'USER_NOT_FOUND';

    users[index].pass = newPass;
    localStorage.setItem('appUsers', JSON.stringify(users));
    
    const newCodes = { ...resetCodes };
    delete newCodes[userOrEmail];
    setResetCodes(newCodes);
    
    return 'SUCCESS';
  };

  const changePassword = (currentPass: string, newPass: string) => 'SUCCESS' as const;

  const updateAccountDetails = (details: UpdatableAccountDetails): boolean => {
    if (accountDetails) {
      const updatedDetails = { ...accountDetails, ...details };
      setAccountDetails(updatedDetails);
      localStorage.setItem('currentUser', JSON.stringify(updatedDetails));
      
      const users = getUsersFromStorage();
      const index = users.findIndex(u => u.user === accountDetails.user);
      if (index >= 0) {
        users[index] = { ...users[index], ...details };
        localStorage.setItem('appUsers', JSON.stringify(users));
      }
      return true;
    }
    return false;
  };

  const value = useMemo(() => ({ 
    isAuthenticated, 
    isAwaitingVerification, 
    licenseInfo, 
    devices, 
    accountDetails, 
    login, 
    verifyLogin, 
    logout, 
    logoutDevice, 
    activate, 
    register, 
    deleteUser,
    getAllUsers,
    sendPasswordResetCode, 
    resetPassword, 
    changePassword, 
    updateAccountDetails 
  }), [isAuthenticated, isAwaitingVerification, licenseInfo, devices, accountDetails, getAllUsers, resetCodes]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};